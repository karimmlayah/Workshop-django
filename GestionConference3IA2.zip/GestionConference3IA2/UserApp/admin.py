from django.contrib import admin
from .models import User, Organizing_committee_member

# Register your models here.
admin.site.register (User)
admin.site.register (Organizing_committee_member)